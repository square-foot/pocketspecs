/*
chunk("Set a variable to catch result","initval",["result"])
chunk("Creating a record as per POST block","savenewrecordvalidated",["!coll","!data","newrec","!result"])
chunk("Return true or false, as per creation","ending",[])
*/
//@initval
result = false;
//@ending 
if(!result){
    return c.json(200,{success: false});
}else {
 return c.json(200,{success: true});
}