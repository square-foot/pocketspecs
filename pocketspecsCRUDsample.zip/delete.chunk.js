/*
chunk("Set a variable to catch result","initval",["result"])
chunk("Deleting a record of a collection as per id param","deleterecord",["!coll","!recid","!result"])
chunk("Return true or false, as per delete success","ending",[])
*/
//@initval
result = false;
//@ending 
if(!result){
    return c.json(200,{success: false});
}else {
 return c.json(200,{success: true});
}