/*
chunk("Set a variable to catch result","initval",["result"])
chunk("Updating a record of a collection as per id param","updaterecord",["!coll","!recid","!data","!result","record"])
chunk("Return true or false, as per update success","ending",[])
*/
//@initval
result = false;
//@ending 
if(!result){
    return c.json(200,{success: false});
}else {
 return c.json(200,{success: true, updated: record});
}