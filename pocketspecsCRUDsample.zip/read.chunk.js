/*
chunk("Set a variable to catch result","initval",["result","dat"])
chunk("Fetch records as per POST block","fetchrecords",["!coll","!dat","records","!result"])
chunk("Return true or false, as per reading","ending",[])
*/
//@initval
result = false;
dat = {
    filter:filt,
    sort:sort,
    limit:+limit,
    offset:+offset
}
//@ending
if(!result){
    return c.json(200,{success: false});
}else {
 return c.json(200,{success: true, recs: records, count: records.length});
}