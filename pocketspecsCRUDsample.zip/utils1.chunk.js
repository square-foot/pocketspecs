/*
chunk("Set some variables","initval",["result","dat"])
*/
//@initval 
//to be written