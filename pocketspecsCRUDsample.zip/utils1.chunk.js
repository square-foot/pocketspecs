/*
chunk("Convert to localtime","code",[])
*/
//@code

  // Create a Date object from the Unix timestamp (in milliseconds)
  const myDate = new Date(unixTimestamp * 1000);

  // Get the current time zone offset in milliseconds
  const timezoneOffset = myDate.getTimezoneOffset() * 60000;

  // Calculate the Indian Standard Time (IST) offset in milliseconds
  const istOffset = 5.5 * 60 * 60 * 1000; // 5.5 hours ahead of UTC

  // Adjust the date object to the IST timezone
  myDate.setTime(myDate.getTime() + timezoneOffset + istOffset);

  // Format the date and time as desired (e.g., using a library like moment.js)
  const formattedDate = myDate.toLocaleString('en-IN', {
    hour12: false, // Use 24-hour format
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric'
  });

  return formattedDate;
